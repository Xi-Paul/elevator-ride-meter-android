package kr.xi.ridemeter

import kotlin.math.abs
import kotlin.math.max

object Report {

    class Meta(
        val site: String,
        val unit: String,
        val spec: String,
        val by: String,
        val addr: String,
        val lat: Double,
        val lon: Double,
        val acc: Double,
        val hasGeo: Boolean
    )

    private fun esc(t: String): String = t
        .replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    private fun f(x: Float) = "%.2f".format(x)

    private fun svgChart(S: List<Smp>): String {
        val w = 760f; val h = 240f
        val l = 46f; val r = 10f; val t = 12f; val b = 26f
        val cw = w - l - r; val ch = h - t - b; val mid = t + ch / 2f
        val dur = max(S[S.size - 1].t, 0.001f)
        var am = 0.5f; var vm = 0.5f; var jm = 0.5f
        for (p in S) { am = max(am, abs(p.a)); vm = max(vm, abs(p.v)); jm = max(jm, abs(p.j)) }
        val step = max(1, S.size / 700)
        val sb = StringBuilder()
        sb.append("""<line x1="$l" y1="$mid" x2="${l + cw}" y2="$mid" stroke="#c8ceda"/>""")
        val gstep = if (dur > 30) 10f else if (dur > 12) 5f else 2f
        var g = 0f
        while (g <= dur) {
            val x = l + g / dur * cw
            sb.append("""<line x1="$x" y1="$t" x2="$x" y2="${t + ch}" stroke="#eceff4"/>""")
            sb.append("""<text x="$x" y="${h - 8}" font-size="10" fill="#6b7383" text-anchor="middle">%.0f</text>""".format(g))
            g += gstep
        }
        val sg = Dsp.segments(S)
        if (sg != null) {
            for (i in intArrayOf(sg.a0, sg.a1, sg.d0, sg.d1)) {
                val x = l + S[i].t / dur * cw
                sb.append("""<line x1="$x" y1="$t" x2="$x" y2="${t + ch}" stroke="#9aa4b5" stroke-dasharray="3 3"/>""")
            }
            fun lab(i0: Int, i1: Int, s: String) {
                val x = l + (S[i0].t + S[i1].t) / 2f / dur * cw
                sb.append("""<text x="$x" y="${t + 12}" font-size="10" fill="#6b7383" text-anchor="middle">$s</text>""")
            }
            lab(sg.a0, sg.a1, "가속"); lab(sg.c0, sg.c1, "등속"); lab(sg.d0, sg.d1, "감속")
        }
        fun poly(which: Int, scale: Float, col: String) {
            val pts = StringBuilder()
            var i = 0
            while (i < S.size) {
                val p = S[i]
                val vv = when (which) { 0 -> p.a; 1 -> p.v; else -> p.j }
                pts.append("%.1f,%.1f ".format(l + p.t / dur * cw, mid - vv / (scale * 1.1f) * (ch / 2f)))
                i += step
            }
            sb.append("""<polyline fill="none" stroke="$col" stroke-width="1.4" points="$pts"/>""")
        }
        poly(2, jm, "#d9534f"); poly(1, vm, "#2b7fc4"); poly(0, am, "#d99a1a")
        sb.append("""<text x="$l" y="${h - 8}" font-size="10" fill="#6b7383">s</text>""")
        sb.append("""<text x="${l + cw}" y="${h - 8}" font-size="10" fill="#6b7383" text-anchor="end">a ±${f(am)} m/s² · v ±${f(vm)} m/s · j ±%.1f m/s³</text>""".format(jm))
        return """<svg viewBox="0 0 ${w.toInt()} ${h.toInt()}" width="100%" xmlns="http://www.w3.org/2000/svg">$sb</svg>"""
    }

    fun build(
        order: List<String>, runs: Map<String, Run>, meta: Meta,
        fcA: String, fcJ: String, dateStr: String
    ): String {
        val sum = StringBuilder(
            "<table><tr><th>회차</th><th>a max</th><th>a min</th><th>v max</th><th>v min</th>" +
                "<th>j max</th><th>j min</th><th>주행시간</th><th>거리</th><th>fs</th></tr>"
        )
        for (k in order) {
            val r = runs[k] ?: continue
            val o = Dsp.stats(r.samples)
            val p = r.samples[r.samples.size - 1]
            sum.append(
                "<tr><td>${name(k)}</td><td>${f(o.aMax)}</td><td>${f(o.aMin)}</td>" +
                    "<td>${f(o.vMax)}</td><td>${f(o.vMin)}</td><td>${f(o.jMax)}</td><td>${f(o.jMin)}</td>" +
                    "<td>%.1f s</td><td>${f(p.s)} m</td><td>%.0f Hz</td></tr>".format(p.t, r.fs)
            )
        }
        sum.append("</table>")

        val avg = StringBuilder("<table><tr><th>방향</th><th>회수</th><th>|v| max 평균</th><th>|a| max 평균</th><th>|j| max 평균</th><th>거리 평균</th></tr>")
        for (dir in listOf("up", "down")) {
            val g = order.filter { it.startsWith(dir) }.mapNotNull { runs[it] }
            if (g.isEmpty()) continue
            var sv = 0f; var sa = 0f; var sj = 0f; var sd = 0f
            for (r in g) {
                val o = Dsp.stats(r.samples)
                sv += max(abs(o.vMax), abs(o.vMin))
                sa += max(abs(o.aMax), abs(o.aMin))
                sj += max(abs(o.jMax), abs(o.jMin))
                sd += r.samples[r.samples.size - 1].s
            }
            val n = g.size.toFloat()
            avg.append(
                "<tr><td>${if (dir == "up") "상승" else "하강"}</td><td>${g.size}</td>" +
                    "<td>${f(sv / n)}</td><td>${f(sa / n)}</td><td>${f(sj / n)}</td><td>${f(sd / n)}</td></tr>"
            )
        }
        avg.append("</table>")

        val body = StringBuilder()
        for (k in order) {
            val r = runs[k] ?: continue
            val S = r.samples
            val o = Dsp.stats(S)
            val p = S[S.size - 1]
            val fft = StringBuilder("<table><tr><th>구간</th><th>길이</th><th>fs</th><th>Δf</th><th>피크 1</th><th>피크 2</th><th>피크 3</th></tr>")
            for (wseg in listOf("acc", "const", "dec")) {
                val sp = Dsp.spectrum(r, wseg) ?: continue
                fun pk(i: Int): String =
                    if (sp.peaks.size > i) "%.2f Hz / %.4f".format(sp.peaks[i][0], sp.peaks[i][1]) else "—"
                fft.append(
                    "<tr><td>${sp.segName}${if (sp.fallback) "*" else ""}</td>" +
                        "<td>%.1f s</td><td>%.0f Hz</td><td>%.2f Hz</td>".format(sp.dur, sp.fs, sp.df) +
                        "<td>${pk(0)}</td><td>${pk(1)}</td><td>${pk(2)}</td></tr>"
                )
            }
            fft.append("</table><p class=\"note\">피크 = 주파수 / 진폭(m/s²), 원시 가속도 기준. * 는 구간 샘플 부족으로 전체 구간 대체.</p>")
            body.append(
                "<section><h3>${name(k)}</h3>${svgChart(S)}" +
                    "<table><tr><th>항목</th><th>max</th><th>min</th></tr>" +
                    "<tr><td>가속도 (m/s²)</td><td>${f(o.aMax)}</td><td>${f(o.aMin)}</td></tr>" +
                    "<tr><td>속도 (m/s)</td><td>${f(o.vMax)}</td><td>${f(o.vMin)}</td></tr>" +
                    "<tr><td>저크 (m/s³)</td><td>${f(o.jMax)}</td><td>${f(o.jMin)}</td></tr></table>" +
                    "<p class=\"note\">주행 시간 %.1f s · 이동 거리 ${f(p.s)} m · 샘플 ${S.size} @ %.0f Hz · 센서 ${esc(r.sensorName)} · 드리프트 보정 %.1f mm/s²</p>"
                        .format(p.t, r.fs, r.bias * 1000f) + fft + "</section>"
            )
        }

        val geoLine = if (meta.hasGeo)
            "위치 %.6f, %.6f (±%.0f m) · <a href=\"https://www.google.com/maps?q=%.6f,%.6f\">지도</a><br>"
                .format(meta.lat, meta.lon, meta.acc, meta.lat, meta.lon)
        else ""

        return """<!DOCTYPE html><html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>승강기 주행 계측 리포트</title><style>
body{font-family:system-ui,"Noto Sans KR",sans-serif;color:#1b2029;max-width:840px;margin:0 auto;padding:24px 18px 60px;line-height:1.55}
h1{font-size:21px;margin:0 0 4px}
h2{font-size:15px;margin:22px 0 6px;color:#42506b}
h3{font-size:16px;margin:26px 0 8px;padding-bottom:4px;border-bottom:2px solid #1b2029}
table{width:100%;border-collapse:collapse;font-size:12.5px;margin:6px 0 4px}
th,td{border:1px solid #d5dae3;padding:5px 7px;text-align:right}
th{background:#f2f4f8;font-weight:600}
td:first-child,th:first-child{text-align:left}
.note{font-size:11.5px;color:#6b7383;margin:4px 0 0}
.hdr{font-size:12.5px;color:#42506b;margin:0 0 14px}
svg{border:1px solid #e3e7ee;border-radius:6px;background:#fff;margin:4px 0}
.lg{font-size:11.5px;color:#6b7383}
.lg i{display:inline-block;width:13px;height:3px;vertical-align:middle;margin:0 4px 0 10px}
@media print{section{break-inside:avoid}}
</style></head><body>
<h1>승강기 주행 계측 리포트</h1>
<p class="hdr">현장 ${esc(meta.site).ifEmpty { "—" }} · 호기/기종 ${esc(meta.unit).ifEmpty { "—" }} · 사양 ${esc(meta.spec).ifEmpty { "—" }}<br>
${if (meta.addr.isNotEmpty()) "주소 " + esc(meta.addr) + "<br>" else ""}$geoLine
측정자 ${esc(meta.by).ifEmpty { "—" }} · 작성 ${esc(dateStr)}</p>
<h2>1. 전 회차 측정값</h2>$sum
<h2>2. 방향별 평균</h2>$avg
<h2>3. 회차별 상세</h2>
<p class="lg"><i style="background:#d99a1a"></i>가속도<i style="background:#2b7fc4"></i>속도<i style="background:#d9534f"></i>저크</p>
$body
<p class="note" style="margin-top:22px">측정: 스마트폰 3축 가속도계, 정지 시 중력벡터에 투영한 연직 성분.
가속도 $fcA Hz / 저크 $fcJ Hz 2단 저역통과. 속도·거리는 사다리꼴 적분 후 종료 시 v=0 조건으로 선형 드리프트 보정.
FFT는 필터 전 원시 가속도에 Hann 윈도우 적용.</p>
</body></html>"""
    }

    fun name(key: String): String {
        val dir = if (key.startsWith("up")) "상승" else "하강"
        val n = key.filter { it.isDigit() }
        return "$dir ${n}회"
    }
}
