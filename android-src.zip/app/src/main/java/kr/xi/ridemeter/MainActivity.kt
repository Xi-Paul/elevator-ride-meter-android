package kr.xi.ridemeter

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.ToggleButton
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

class MainActivity : AppCompatActivity(), SensorEventListener {

    // ---- 상태 ----
    private val runs = HashMap<String, Run>()
    private var dir = "up"
    private var trial = 1
    private var nTrials = 3
    private var recKey: String? = null

    private lateinit var sm: SensorManager
    private var sensor: Sensor? = null
    private var sensorLabel = ""

    private var calib = true
    private var calibN = 0
    private var calibX = 0.0; private var calibY = 0.0; private var calibZ = 0.0
    private var calibT0 = 0L
    private var gx = 0f; private var gy = 0f; private var gz = 0f; private var gMag = 9.81f

    private var t0 = 0L
    private var lastT = 0f
    private var lastA = 0f
    private var vAcc = 0f
    private var sAcc = 0f
    private val aSt = FloatArray(2)
    private val jSt = FloatArray(2)

    // 자동정지 상태기계
    private var phase = "wait"
    private var phT = 0f
    private var sA = 0f

    private var geoLat = 0.0; private var geoLon = 0.0; private var geoAcc = 0.0
    private var hasGeo = false

    private val ui = Handler(Looper.getMainLooper())
    private var pendingCsv: String? = null
    private var pendingHtml: String? = null

    // ---- 뷰 ----
    private lateinit var chart: ChartView
    private lateinit var tvFs: TextView
    private lateinit var tvA: TextView
    private lateinit var tvV: TextView
    private lateinit var tvJ: TextView
    private lateinit var tvAmm: TextView
    private lateinit var tvVmm: TextView
    private lateinit var tvJmm: TextView
    private lateinit var tvStats: TextView
    private lateinit var tvSummary: TextView
    private lateinit var tvMsg: TextView
    private lateinit var tvGeo: TextView
    private lateinit var btnGo: Button
    private lateinit var btnUp: Button
    private lateinit var btnDown: Button
    private lateinit var trialBar: LinearLayout
    private lateinit var spRate: Spinner
    private lateinit var spAuto: Spinner
    private lateinit var spFc: Spinner
    private lateinit var spJfc: Spinner
    private lateinit var spSeg: Spinner
    private lateinit var spTrials: Spinner
    private lateinit var tgFft: ToggleButton
    private lateinit var cbA: CheckBox
    private lateinit var cbV: CheckBox
    private lateinit var cbJ: CheckBox
    private lateinit var cbR: CheckBox
    private lateinit var cbUncal: CheckBox
    private lateinit var edSite: EditText
    private lateinit var edUnit: EditText
    private lateinit var edSpec: EditText
    private lateinit var edBy: EditText
    private lateinit var edAddr: EditText

    private val RATES = intArrayOf(0, 100, 200, 400, 800)
    private val RATE_LABELS = arrayOf("최대", "100 Hz", "200 Hz", "400 Hz", "800 Hz")
    private val AUTO_S = floatArrayOf(0f, 1f, 2f, 3f, 5f, 10f, 15f, 20f, 30f, 45f, 60f)
    private val AUTO_LABELS = arrayOf("끔", "1 s", "2 s", "3 s", "5 s", "10 s", "15 s", "20 s", "30 s", "45 s", "60 s")
    private val FC = arrayOf("2", "3", "5", "8", "12", "20")
    private val JFC = arrayOf("1", "2", "4", "8")
    private val SEG_KEY = arrayOf("const", "acc", "dec", "all")
    private val SEG_LABELS = arrayOf("등속", "가속", "감속", "전체")

    private val saveCsv = registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        writeUri(uri, pendingCsv); pendingCsv = null
    }
    private val saveHtml = registerForActivityResult(ActivityResultContracts.CreateDocument("text/html")) { uri ->
        writeUri(uri, pendingHtml); pendingHtml = null
    }
    private val openCsv = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importCsv(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        chart = findViewById(R.id.chart)
        tvFs = findViewById(R.id.tvFs)
        tvA = findViewById(R.id.tvA); tvV = findViewById(R.id.tvV); tvJ = findViewById(R.id.tvJ)
        tvAmm = findViewById(R.id.tvAmm); tvVmm = findViewById(R.id.tvVmm); tvJmm = findViewById(R.id.tvJmm)
        tvStats = findViewById(R.id.tvStats)
        tvSummary = findViewById(R.id.tvSummary)
        tvMsg = findViewById(R.id.tvMsg)
        tvGeo = findViewById(R.id.tvGeo)
        btnGo = findViewById(R.id.btnGo)
        btnUp = findViewById(R.id.btnUp); btnDown = findViewById(R.id.btnDown)
        trialBar = findViewById(R.id.trialBar)
        spRate = findViewById(R.id.spRate); spAuto = findViewById(R.id.spAuto)
        spFc = findViewById(R.id.spFc); spJfc = findViewById(R.id.spJfc); spSeg = findViewById(R.id.spSeg)
        spTrials = findViewById(R.id.spTrials)
        tgFft = findViewById(R.id.tgFft)
        cbA = findViewById(R.id.cbA); cbV = findViewById(R.id.cbV)
        cbJ = findViewById(R.id.cbJ); cbR = findViewById(R.id.cbR)
        cbUncal = findViewById(R.id.cbUncal)
        edSite = findViewById(R.id.edSite); edUnit = findViewById(R.id.edUnit)
        edSpec = findViewById(R.id.edSpec); edBy = findViewById(R.id.edBy); edAddr = findViewById(R.id.edAddr)

        sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager

        fillSpinner(spRate, RATE_LABELS, 2)
        fillSpinner(spAuto, AUTO_LABELS, 1)
        fillSpinner(spFc, FC.map { "$it Hz" }.toTypedArray(), 1)
        fillSpinner(spJfc, JFC.map { "$it Hz" }.toTypedArray(), 1)
        fillSpinner(spSeg, SEG_LABELS, 0)
        fillSpinner(spTrials, arrayOf("1회", "2회", "3회", "4회", "5회"), 2)

        spTrials.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                nTrials = pos + 1
                if (trial > nTrials) trial = nTrials
                buildTrials(); refresh()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        spSeg.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) = refresh()
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        btnUp.setOnClickListener { dir = "up"; refresh() }
        btnDown.setOnClickListener { dir = "down"; refresh() }
        btnGo.setOnClickListener { if (recKey == key()) stopRec(false) else startRec() }
        findViewById<Button>(R.id.btnCsv).setOnClickListener { exportCsv() }
        findViewById<Button>(R.id.btnLoad).setOnClickListener { openCsv.launch(arrayOf("text/csv", "text/comma-separated-values", "text/plain", "*/*")) }
        findViewById<Button>(R.id.btnReset).setOnClickListener { resetCur() }
        findViewById<Button>(R.id.btnReport).setOnClickListener { exportReport() }
        findViewById<Button>(R.id.btnGeo).setOnClickListener { requestGeo() }

        val redraw = View.OnClickListener { refresh() }
        cbA.setOnClickListener(redraw); cbV.setOnClickListener(redraw)
        cbJ.setOnClickListener(redraw); cbR.setOnClickListener(redraw)
        tgFft.setOnClickListener(redraw)

        loadAll()
        buildTrials()
        refresh()
        msg("휴대폰을 카 바닥이나 손잡이에 고정하고, 정지 상태에서 시작을 누르세요.")
    }

    private fun fillSpinner(sp: Spinner, items: Array<String>, sel: Int) {
        val ad = ArrayAdapter(this, android.R.layout.simple_spinner_item, items)
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        sp.adapter = ad
        sp.setSelection(sel)
    }

    private fun key() = dir + trial
    private fun getRun(k: String): Run = runs.getOrPut(k) { Run() }
    private fun msg(t: String) { tvMsg.text = t }

    // ---- 회차 칩 ----
    private fun buildTrials() {
        trialBar.removeAllViews()
        for (n in 1..nTrials) {
            val b = Button(this)
            b.text = "${n}회"
            b.textSize = 12f
            b.setBackgroundResource(R.drawable.chip_bg)
            b.setTextColor(0xFFE8EDF5.toInt())
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.marginEnd = 6
            b.layoutParams = lp
            b.setOnClickListener { trial = n; refresh() }
            trialBar.addView(b)
        }
    }

    // ---- 기록 ----
    private fun startRec() {
        if (recKey != null) { msg("다른 회차를 기록 중입니다."); return }
        val uncal = cbUncal.isChecked
        var s: Sensor? = null
        if (uncal && Build.VERSION.SDK_INT >= 26) s = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER_UNCALIBRATED)
        if (s == null) s = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        if (s == null) { msg("가속도 센서를 찾을 수 없습니다."); return }
        sensor = s
        sensorLabel = if (s.type == Sensor.TYPE_ACCELEROMETER_UNCALIBRATED) "무보정" else "표준"

        val rate = RATES[spRate.selectedItemPosition]
        val periodUs = if (rate == 0) SensorManager.SENSOR_DELAY_FASTEST else (1_000_000 / rate)

        val k = key()
        runs[k] = Run()
        recKey = k
        calib = true; calibN = 0; calibX = 0.0; calibY = 0.0; calibZ = 0.0; calibT0 = 0L
        aSt[0] = 0f; aSt[1] = 0f; jSt[0] = 0f; jSt[1] = 0f
        phase = "wait"; phT = 0f; sA = 0f
        tgFft.isChecked = false

        val ok = sm.registerListener(this, s, periodUs)
        if (!ok) { recKey = null; msg("센서 등록에 실패했습니다."); return }
        refresh()
        msg("[${Report.name(k)}] 영점 잡는 중… 2초간 움직이지 마세요.")
    }

    private fun stopRec(auto: Boolean) {
        val k = recKey ?: return
        sm.unregisterListener(this)
        recKey = null
        val r = getRun(k)
        if (r.samples.size < 10) {
            runs[k] = Run(); refresh(); msg("데이터가 부족합니다. 다시 시도하세요."); return
        }
        r.bias = Dsp.debias(r.samples)
        r.done = true
        r.sensorName = sensorLabel
        saveRun(k, r)
        refresh()
        msg("[${Report.name(k)}] ${if (auto) "정지 감지 → 자동 종료" else "기록 종료"} · %.0f Hz · 드리프트 %.1f mm/s²".format(r.fs, r.bias * 1000f))
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    override fun onSensorChanged(e: SensorEvent) {
        val k = recKey ?: return
        val r = getRun(k)
        val x = e.values[0]; val y = e.values[1]; val z = e.values[2]

        if (calib) {
            if (calibT0 == 0L) calibT0 = e.timestamp
            calibX += x; calibY += y; calibZ += z; calibN++
            val el = (e.timestamp - calibT0) / 1e9
            if (el >= 2.0 && calibN > 4) {
                val mx = (calibX / calibN).toFloat()
                val my = (calibY / calibN).toFloat()
                val mz = (calibZ / calibN).toFloat()
                gMag = sqrt(mx * mx + my * my + mz * mz)
                if (gMag < 1f) { msg("중력값이 비정상입니다. 다시 시도하세요."); stopRec(false); return }
                gx = mx / gMag; gy = my / gMag; gz = mz / gMag
                r.fs = (calibN / el).toFloat()
                calib = false
                t0 = e.timestamp; lastT = 0f; lastA = 0f; vAcc = 0f; sAcc = 0f
                ui.post {
                    msg("[${Report.name(k)}] 영점 완료 · $sensorLabel %.0f Hz (|g| = %.3f). 기록 중.".format(r.fs, gMag))
                    refresh()
                }
                startTicker()
            }
            return
        }

        val t = ((e.timestamp - t0) / 1e9).toFloat()
        val dt = t - lastT
        if (dt <= 0f || dt > 0.5f) { lastT = t; return }
        lastT = t

        val ar = x * gx + y * gy + z * gz - gMag
        val fcA = FC[spFc.selectedItemPosition].toFloat()
        val fcJ = JFC[spJfc.selectedItemPosition].toFloat()
        val a = lpf(ar, dt, fcA, aSt)
        val j = lpf((a - lastA) / dt, dt, fcJ, jSt)
        vAcc += (a + lastA) / 2f * dt
        sAcc += vAcc * dt
        lastA = a
        r.samples.add(Smp(t, ar, a, vAcc, j, sAcc))
        if (r.samples.size % 64 == 0) r.fs = r.samples.size / max(t, 0.001f)

        val holdIdx = spAuto.selectedItemPosition
        val hold = AUTO_S[holdIdx]
        if (hold > 0f) {
            val hi = 0.15f; val lo = 0.05f
            when (phase) {
                "wait" -> if (abs(a) > hi) { phT += dt; if (phT >= 0.3f) { phase = "acc"; sA = Dsp.sgn(a); phT = 0f } } else phT = 0f
                "acc", "cruise" -> {
                    if (a * sA < -hi) { phT += dt; if (phT >= 0.3f) { phase = "dec"; phT = 0f } }
                    else { phT = 0f; if (phase == "acc" && abs(a) < lo) phase = "cruise" }
                }
                "dec" -> {
                    if (abs(a) < lo) { phT += dt; if (phT >= hold) { ui.post { stopRec(true) } ; return } }
                    else phT = 0f
                }
            }
        }
    }

    private fun lpf(x: Float, dt: Float, fc: Float, st: FloatArray): Float {
        val rc = 1f / (2f * PI.toFloat() * fc)
        val al = dt / (rc + dt)
        st[0] += al * (x - st[0])
        st[1] += al * (st[0] - st[1])
        return st[1]
    }

    private val ticker = object : Runnable {
        override fun run() {
            if (recKey == null) return
            refresh()
            ui.postDelayed(this, 120)
        }
    }
    private fun startTicker() { ui.removeCallbacks(ticker); ui.postDelayed(ticker, 120) }

    // ---- 표시 ----
    private fun refresh() {
        val k = key()
        val r = getRun(k)
        btnUp.isSelected = dir == "up"
        btnDown.isSelected = dir == "down"
        for (i in 0 until trialBar.childCount) {
            val b = trialBar.getChildAt(i) as Button
            val n = i + 1
            b.isSelected = n == trial
            val rr = runs[dir + n]
            b.text = "${n}회" + if (recKey == dir + n) " ●" else if (rr != null && rr.samples.isNotEmpty()) " ✓" else ""
        }
        tvFs.text = if (r.fs > 0f) "%.0f Hz%s".format(r.fs, if (recKey == k) " · $phase" else "") else "— Hz"

        val S = r.samples
        if (S.isEmpty()) {
            tvA.text = "0.00"; tvV.text = "0.00"; tvJ.text = "0.00"
            tvAmm.text = "max 0.00\nmin 0.00"; tvVmm.text = "max 0.00\nmin 0.00"; tvJmm.text = "max 0.00\nmin 0.00"
            tvStats.text = "데이터 없음"
        } else {
            val p = S[S.size - 1]
            val o = Dsp.stats(S)
            tvA.text = "%.2f".format(p.a); tvV.text = "%.2f".format(p.v); tvJ.text = "%.2f".format(p.j)
            tvAmm.text = "max %.2f\nmin %.2f".format(o.aMax, o.aMin)
            tvVmm.text = "max %.2f\nmin %.2f".format(o.vMax, o.vMin)
            tvJmm.text = "max %.2f\nmin %.2f".format(o.jMax, o.jMin)
            tvStats.text = "주행 %.1f s · 거리 %.2f m · 샘플 %d · 드리프트 %.1f mm/s² · 센서 %s"
                .format(p.t, p.s, S.size, r.bias * 1000f, if (r.sensorName.isEmpty()) "—" else r.sensorName)
        }

        chart.runData = r
        chart.title = Report.name(k)
        chart.showA = cbA.isChecked; chart.showV = cbV.isChecked
        chart.showJ = cbJ.isChecked; chart.showR = cbR.isChecked
        chart.fftMode = tgFft.isChecked
        chart.spec = if (tgFft.isChecked && r.done) Dsp.spectrum(r, SEG_KEY[spSeg.selectedItemPosition]) else null
        chart.invalidate()

        btnGo.text = when {
            recKey == k -> "정지"
            recKey != null -> "${Report.name(recKey!!)} 기록 중"
            S.isNotEmpty() -> "${Report.name(k)} 다시 측정"
            else -> "${Report.name(k)} 시작"
        }
        btnGo.isEnabled = recKey == null || recKey == k

        val sb = StringBuilder("회차      a max/min    v max/min    j max/min   거리\n")
        for (d in listOf("up", "down")) for (n in 1..nTrials) {
            val rr = runs[d + n]
            val nm = (if (d == "up") "상승" else "하강") + n
            if (rr == null || rr.samples.isEmpty()) { sb.append("%-8s —\n".format(nm)); continue }
            val o = Dsp.stats(rr.samples)
            sb.append("%-8s %5.2f/%5.2f %5.2f/%5.2f %5.2f/%5.2f %5.2f\n"
                .format(nm, o.aMax, o.aMin, o.vMax, o.vMin, o.jMax, o.jMin, rr.samples[rr.samples.size - 1].s))
        }
        tvSummary.text = sb.toString()
    }

    private fun resetCur() {
        if (recKey != null) return
        runs.remove(key())
        File(filesDir, key() + ".csv").delete()
        refresh(); msg("[${Report.name(key())}] 초기화됨.")
    }

    // ---- 저장 / 불러오기 ----
    private fun runToCsv(r: Run): String {
        val sb = StringBuilder("t_s,a_raw_mps2,a_filt_mps2,v_mps,jerk_mps3,s_m\n")
        for (p in r.samples)
            sb.append("%.5f,%.5f,%.5f,%.5f,%.5f,%.5f\n".format(p.t, p.ar, p.a, p.v, p.j, p.s))
        return sb.toString()
    }

    private fun saveRun(k: String, r: Run) {
        try { File(filesDir, "$k.csv").writeText(runToCsv(r)) } catch (_: Exception) {}
    }

    private fun loadAll() {
        for (d in listOf("up", "down")) for (n in 1..5) {
            val f = File(filesDir, "$d$n.csv")
            if (!f.exists()) continue
            try {
                val r = parseCsv(f.readText()) ?: continue
                runs["$d$n"] = r
            } catch (_: Exception) {}
        }
    }

    private fun parseCsv(text: String): Run? {
        val lines = text.split("\n").filter { it.isNotBlank() }
        if (lines.size < 3) return null
        val head = lines[0].split(",").map { it.trim() }
        val iT = head.indexOf("t_s"); val iA = head.indexOf("a_filt_mps2")
        if (iT < 0 || iA < 0) return null
        val iAr = head.indexOf("a_raw_mps2"); val iV = head.indexOf("v_mps")
        val iJ = head.indexOf("jerk_mps3"); val iS = head.indexOf("s_m")
        val r = Run()
        for (i in 1 until lines.size) {
            val c = lines[i].split(",")
            val t = c.getOrNull(iT)?.toFloatOrNull() ?: continue
            val a = c.getOrNull(iA)?.toFloatOrNull() ?: continue
            r.samples.add(Smp(
                t,
                if (iAr >= 0) c.getOrNull(iAr)?.toFloatOrNull() ?: a else a,
                a,
                if (iV >= 0) c.getOrNull(iV)?.toFloatOrNull() ?: 0f else 0f,
                if (iJ >= 0) c.getOrNull(iJ)?.toFloatOrNull() ?: 0f else 0f,
                if (iS >= 0) c.getOrNull(iS)?.toFloatOrNull() ?: 0f else 0f
            ))
        }
        if (r.samples.size < 2) return null
        r.done = true
        r.fs = (r.samples.size - 1) / max(r.samples[r.samples.size - 1].t, 0.001f)
        return r
    }

    private fun exportCsv() {
        val r = runs[key()]
        if (r == null || r.samples.isEmpty()) { msg("저장할 데이터가 없습니다."); return }
        pendingCsv = runToCsv(r)
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.KOREA).format(Date())
        saveCsv.launch("elevator_${key()}_$stamp.csv")
    }

    private fun importCsv(uri: Uri) {
        try {
            val txt = contentResolver.openInputStream(uri)?.bufferedReader()?.readText() ?: return
            val r = parseCsv(txt)
            if (r == null) { msg("이 앱에서 저장한 CSV 형식이 아닙니다."); return }
            r.src = uri.lastPathSegment
            runs[key()] = r
            saveRun(key(), r)
            refresh(); msg("[${Report.name(key())}] 불러왔습니다.")
        } catch (e: Exception) { msg("불러오기 실패: ${e.message}") }
    }

    private fun exportReport() {
        val order = ArrayList<String>()
        for (d in listOf("up", "down")) for (n in 1..nTrials) {
            val r = runs[d + n]
            if (r != null && r.samples.isNotEmpty()) order.add(d + n)
        }
        if (order.isEmpty()) { msg("리포트에 포함할 데이터가 없습니다."); return }
        val meta = Report.Meta(
            edSite.text.toString(), edUnit.text.toString(), edSpec.text.toString(),
            edBy.text.toString(), edAddr.text.toString(), geoLat, geoLon, geoAcc, hasGeo
        )
        val date = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.KOREA).format(Date())
        pendingHtml = Report.build(order, runs, meta, FC[spFc.selectedItemPosition], JFC[spJfc.selectedItemPosition], date)
        val stamp = SimpleDateFormat("yyyyMMdd", Locale.KOREA).format(Date())
        val unit = edUnit.text.toString().replace(Regex("\\s+"), "").ifEmpty { "unit" }
        saveHtml.launch("ride_report_${unit}_$stamp.html")
    }

    private fun writeUri(uri: Uri?, content: String?) {
        if (uri == null || content == null) return
        try {
            contentResolver.openOutputStream(uri)?.use { it.write(content.toByteArray()) }
            msg("저장했습니다.")
        } catch (e: Exception) { msg("저장 실패: ${e.message}") }
    }

    // ---- 위치 ----
    private fun requestGeo() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 1)
            return
        }
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        tvGeo.text = "위치 확인 중…"
        val listener = object : LocationListener {
            override fun onLocationChanged(loc: Location) {
                lm.removeUpdates(this)
                onGeo(loc)
            }
        }
        try {
            val provider = if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER))
                LocationManager.GPS_PROVIDER else LocationManager.NETWORK_PROVIDER
            lm.requestLocationUpdates(provider, 0L, 0f, listener, Looper.getMainLooper())
            ui.postDelayed({
                lm.removeUpdates(listener)
                if (!hasGeo) tvGeo.text = "위치를 가져오지 못했습니다."
            }, 20000)
        } catch (e: Exception) { tvGeo.text = "위치 오류: ${e.message}" }
    }

    private fun onGeo(loc: Location) {
        geoLat = loc.latitude; geoLon = loc.longitude
        geoAcc = loc.accuracy.toDouble(); hasGeo = true
        tvGeo.text = "%.6f, %.6f (±%.0f m)".format(geoLat, geoLon, geoAcc)
        if (geoAcc > 100) msg("위치 정확도 ±%.0f m — 실내라 오차가 큽니다. 건물 밖에서 다시 시도하세요.".format(geoAcc))
        Thread {
            try {
                val gc = Geocoder(this, Locale.KOREA)
                @Suppress("DEPRECATION")
                val list = gc.getFromLocation(geoLat, geoLon, 1)
                if (!list.isNullOrEmpty()) {
                    val ad = list[0]
                    val name = ad.featureName ?: ""
                    val full = ad.getAddressLine(0) ?: ""
                    ui.post {
                        if (edSite.text.isEmpty() && name.isNotEmpty() && !name.first().isDigit()) edSite.setText(name)
                        if (edAddr.text.isEmpty() && full.isNotEmpty()) edAddr.setText(full)
                        msg(if (full.isNotEmpty()) "위치 확인: $full" else "좌표만 확보했습니다.")
                    }
                }
            } catch (e: Exception) {
                ui.post { msg("좌표는 확보했으나 주소 조회에 실패했습니다.") }
            }
        }.start()
    }

    override fun onRequestPermissionsResult(rc: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(rc, perms, res)
        if (rc == 1 && res.isNotEmpty() && res[0] == PackageManager.PERMISSION_GRANTED) requestGeo()
        else if (rc == 1) msg("위치 권한이 거부되었습니다.")
    }

    override fun onDestroy() {
        super.onDestroy()
        sm.unregisterListener(this)
        ui.removeCallbacksAndMessages(null)
    }
}
