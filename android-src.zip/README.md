# 승강기 주행 계측 (Android)

스마트폰 가속도계로 승강기의 가속도·속도·저크를 측정하고, 구간별 FFT와 시험 리포트를 만드는 앱.

## 웹앱 대비 차이
- `SENSOR_DELAY_FASTEST` + `HIGH_SAMPLING_RATE_SENSORS` 권한으로 200~500 Hz 수집 (웹은 Chromium 정책상 60 Hz 고정)
- 하드웨어 나노초 타임스탬프 → 저크 정확도 향상
- 무보정 가속도계(`TYPE_ACCELEROMETER_UNCALIBRATED`) 선택 가능

## 측정 원리
1. 시작 후 2초간 정지 상태의 3축 평균으로 중력 단위벡터 ĝ와 |g| 산출
2. 연직 가속도 = a·ĝ − |g| (폰 자세와 무관)
3. 2단 1차 저역통과 → 가속도, 미분 후 별도 LPF → 저크
4. 사다리꼴 적분 → 속도·거리, 종료 시 v=0 조건으로 선형 드리프트 제거
5. FFT는 필터 전 원시 가속도에 Hann 윈도우 적용 (코히런트 게인 0.5 보정)

## 빌드
GitHub Actions가 push 시 자동으로 debug APK를 만듭니다.
Actions 탭 → 최근 실행 → Artifacts → `ride-meter-apk` 다운로드 → 설치.
